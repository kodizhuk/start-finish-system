//#include <project.h>
//#include "lib_RTC\RTC_WDT.h"
//
//static uint16_t minMs;
//static uint16_t maxMs;
//uint16_t tmpMs;
//
//void DebugStart(void);
//void DebugPrintResult(void);
///* [] END OF FILE */
//